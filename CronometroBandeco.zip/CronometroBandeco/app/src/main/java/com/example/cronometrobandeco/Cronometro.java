package com.example.cronometrobandeco;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Cronometro extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cronometro);
    }
}